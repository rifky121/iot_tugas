package com.example.tugas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;

import android.os.Bundle;
import android.widget.TextView;

import com.example.tugas.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    DatabaseReference Thing;

    String cahaya;
    String gerakan;
    Float totalcahaya;
    TextView txtpergerakan;
    TextView txtpencahayaan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtpergerakan = (TextView) findViewById(R.id.txtpergerakan);
        txtpencahayaan = (TextView) findViewById(R.id.txtpencahayaan);

        Thing = FirebaseDatabase.getInstance().getReference();
        Thing.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                cahaya = dataSnapshot.child("node1/pir").getValue().toString();
                totalcahaya = Float.parseFloat(cahaya);
                if (totalcahaya >= 4){
                    txtpencahayaan.setText("lampu harus dinyalakan");
                }
                else{
                    txtpencahayaan.setText("lampu dimatikan");
                }

                gerakan = dataSnapshot.child("node1/motion").getValue().toString();
                if (gerakan.equals("0")){
                    txtpergerakan.setText("tidak ada pergerakan");
                }
                else {
                    txtpergerakan.setText("ada pergerakan");
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
